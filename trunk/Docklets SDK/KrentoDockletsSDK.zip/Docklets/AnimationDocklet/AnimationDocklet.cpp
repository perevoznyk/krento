//Simple animation plugin for ObjectDock

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include "../DockletSDK/DockletSDK.h"
#include "CAnimation.h"
#include "resource.h"


int CALLBACK ConfigureDocklet(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);


BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}



void CALLBACK OnGetInformation(LPWSTR szName, LPWSTR szAuthor, int *iVersion, LPWSTR szNotes)
{
	_tcscpy(szName, L"Simple Animation Docklet");
	_tcscpy(szAuthor, L"Jeff Bargmann");
	(*iVersion) = 100;
	_tcscpy(szNotes,   L"A simple animation docklet for ObjectDock");
}

Animation *CALLBACK OnCreate(HWND hwndDocklet, HINSTANCE hInstance, LPWSTR szIni, LPWSTR szIniGroup)
{
	Animation *lpAnimation = new Animation(hwndDocklet, hInstance);

	/////////

	WCHAR szImageToLoad[MAX_PATH+10];
	_tcscpy(szImageToLoad, L"");
	
	if(szIni && szIniGroup)
	{
		//load from ini
		GetPrivateProfileString(szIniGroup, L"AnimationImage", L"", szImageToLoad, MAX_PATH, szIni);
	}
	else
	{
		//Load default options
		DockletSetLabel(lpAnimation->hwndDocklet, L"Animation Docklet!");

		DockletGetRelativeFolder(lpAnimation->hwndDocklet, szImageToLoad);
		_tcscat(szImageToLoad, L"globe.png");
	}
	

	lpAnimation->SetImage(szImageToLoad);


	return lpAnimation;
}

void CALLBACK OnSave(Animation *lpAnimation, LPWSTR szIni, LPWSTR szIniGroup, BOOL bIsForExport)
{
	WCHAR szImage[MAX_PATH+100];
	lpAnimation->GetImage(szImage);
	WritePrivateProfileString(szIniGroup, L"AnimationImage", szImage, szIni);
}

void CALLBACK OnDestroy(Animation *lpAnimation, HWND hwndDocklet)
{
	delete lpAnimation;
	lpAnimation = NULL;
}


BOOL CALLBACK OnLeftButtonClick(Animation *lpAnimation, POINT *ptCursor, SIZE *sizeDocklet)
{
	DockletDoAttentionAnimation(lpAnimation->hwndDocklet);
	return TRUE;
}


int CALLBACK ConfigureDocklet(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	Animation *lpAnimation = (Animation *) GetProp(hDlg, L"lpAnimation");

	switch(iMsg)
	{
	case WM_INITDIALOG:
		SetProp(hDlg, L"lpAnimation", (HANDLE) (WCHAR*) lParam);
		lpAnimation = (Animation *) GetProp(hDlg, L"lpAnimation");
		if(!lpAnimation)
			return TRUE;

		break;

	case WM_COMMAND:
		char szThis[2000];
		strcpy(szThis, "");
		switch(LOWORD(wParam))
		{
		case IDOK:
			if(!lpAnimation)
				break;

			
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return TRUE;
		}
		break;

	case WM_DESTROY:
		RemoveProp(hDlg, L"lpAnimation");
		break;
	}

	return FALSE;
}

void CALLBACK OnConfigure(Animation *lpAnimation)
{
	//Get the animation folder's root, we want to limit image selection to this folder
	WCHAR szBrowseRoot[MAX_PATH+10];
	DockletGetRelativeFolder(lpAnimation->hwndDocklet, szBrowseRoot);
	
	//Show ChooseImage dialog to pick a new image
	WCHAR szCurrentImage[MAX_PATH+10];
	lpAnimation->GetImage(szCurrentImage);
	if(DockletBrowseForImage(NULL, szCurrentImage, szBrowseRoot))
		lpAnimation->SetImage(szCurrentImage);
}

BOOL CALLBACK OnDoubleClick(Animation *lpAnimation, POINT *ptCursor, SIZE *sizeDocklet)
{
	return FALSE;
}

BOOL CALLBACK OnAcceptDropFiles(Animation *lpAnimation)
{
	return FALSE;
}

void CALLBACK OnDropFiles(Animation *lpAnimation, HDROP hDrop)
{
	return;
}
