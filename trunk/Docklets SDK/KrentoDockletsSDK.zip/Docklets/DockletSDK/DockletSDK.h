//Header file for ObjectDock DockletSDK
#pragma once

#include <Gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus.lib")

BOOL DockletIsVisible(HWND hwndDocklet);
BOOL DockletGetRect(HWND hwndDocklet, RECT *rcDocklet);
int DockletGetLabel(HWND hwndDocklet, LPWSTR szLabel);
void DockletSetLabel(HWND hwndDocklet, LPWSTR szLabel);


Bitmap *DockletLoadGDIPlusImage(LPWSTR szImage);
void DockletSetImage(HWND hwndDocklet, Image *lpImageNew, BOOL bAutomaticallyDeleteImage = TRUE);
void DockletSetImageFile(HWND hwndDocklet, LPWSTR szImage);
void DockletSetImageOverlay(HWND hwndDocklet, Image *imageOverlay, BOOL bAutomaticallyDeleteImage = TRUE);

BOOL DockletBrowseForImage(HWND hwndParent, LPWSTR szImage, LPWSTR szAlternateRelativeRoot = NULL);

void DockletLockMouseEffect(HWND hwndDocklet, BOOL bLock);
void DockletDoAttentionAnimation(HWND hwndDocklet);

int WritePrivateProfileInt(LPCTSTR lpAppName, LPWSTR lpKeyName, int iValue, LPCTSTR lpFileName);

void DockletGetRootFolder(HWND hwndDocklet, LPWSTR szFolder);
void DockletGetRelativeFolder(HWND hwndDocklet, LPWSTR szFolder);

void DockletDefaultConfigDialog(HWND hwndDocklet);

int DockletQueryDockEdge(HWND hwndDocklet);
int DockletQueryDockAlign(HWND hwndDocklet);
BOOL DockletSetDockEdge(HWND hwndDocklet, int iNewEdge);
BOOL DockletSetDockAlign(HWND hwndDocklet, int iNewAlign);